# -*- coding: iso-8859-1 -*-
# vim: set ft=python ts=3 sw=3 expandtab:
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #
#
# Author   : Kenneth J. Pronovici <pronovic@ieee.org>
# Language : Python (>= 2.3)
# Project  : WordUtils
# Revision : $Id: release.py,v 1.1 2003/07/16 05:23:04 pronovic Exp $
# Purpose  : Provides location to maintain version information.
#
# # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # # #

"""
Provides location to maintain version information.

@var VERSION: Software version.
@var DATE: Software release date.

@author: Kenneth J. Pronovici <pronovic@ieee.org>
"""

VERSION     = "0.8.1"
DATE        = "04 Apr 2006"

